# -*- coding: utf-8 -*-

from __future__ import print_function, unicode_literals

class ChannelNotFound(Exception): pass
class InternalServerError(Exception): pass
class StreamError(Exception): pass
class NotFound(Exception): pass 
